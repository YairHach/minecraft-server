**This image is now deprecated. **

Please use [itzg/elasticsearch](https://registry.hub.docker.com/u/itzg/elasticsearch/)
instead. See the plugins configuration section for that image to see how
to install Marvel.
