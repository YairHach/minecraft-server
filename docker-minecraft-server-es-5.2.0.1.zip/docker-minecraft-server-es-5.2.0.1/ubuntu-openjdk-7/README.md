Provides the latest OpenJDK JRE on top of Ubuntu Trusty (14.04).
